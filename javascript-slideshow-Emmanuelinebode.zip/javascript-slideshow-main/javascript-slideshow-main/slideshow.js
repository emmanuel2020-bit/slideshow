var current = 0;

var slides = document.getElementsByClassName("slide");
var total = slides.length;

var next = document.getElementById("next");

slides[current].style.display = "block";

function showNextSlide() {
  current++;
  if (current >= total) {
    current = 0;
  }
  for (var i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  slides[current].style.display = "block";
}

next.addEventListener("click", function () {
  console.log("NEXT");
  showNextSlide();
});

setInterval(showNextSlide, 5000);
