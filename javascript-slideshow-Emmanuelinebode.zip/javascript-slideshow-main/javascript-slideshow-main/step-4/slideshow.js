
var current = 0;
var total = 4;